package scala.meta.internal.pc

object MemberOrdering {
  val IsWorkspaceSymbol: Int = 1 << 30
  val IsInheritedBaseMethod: Int = 1 << 29
  val IsImplicitConversion: Int = 1 << 28
  val IsInherited: Int = 1 << 27
  val IsNotLocalByBlock: Int = 1 << 26
  val IsNotDefinedInFile: Int = 1 << 25
  val IsNotTypeInTypePos: Int = 1 << 24
  val IsNotPublic: Int = 1 << 23
  val IsPackage: Int = 1 << 22
  val IsNotCaseAccessor: Int = 1 << 21
  val IsNotGetter: Int = 1 << 20
  val IsSynthetic: Int = 1 << 19
  val IsDeprecated: Int = 1 << 18
  val IsEvilMethod: Int = 1 << 17 // example: clone() and finalize()

  // OverrideDefMember
  val IsNotAbstract: Int = 1 << 30

  def showFlags(value: Int): String = {
    List(
      (IsWorkspaceSymbol, "workspaceSymbol"),
      (IsInheritedBaseMethod, "inheritedBaseMethod"),
      (IsImplicitConversion, "implicitConvertion"),
      (IsInherited, "inherited"),
      (IsNotLocalByBlock, "notLocalByBlock"),
      (IsNotDefinedInFile, "notDefinedInFile"),
      (IsNotTypeInTypePos, "notTypeInTypePosition"),
      (IsNotGetter, "notGetter"),
      (IsPackage, "package"),
      (IsNotCaseAccessor, "notCaseAccessor"),
      (IsNotPublic, "notPublic"),
      (IsSynthetic, "synthetic"),
      (IsDeprecated, "deprecated"),
      (IsEvilMethod, "evilMethod"),
      (IsNotAbstract, "notAbstract")
    ).collect { case (i, name) if (value & i) > 0 => name }
      .mkString(", ")
  }
}
